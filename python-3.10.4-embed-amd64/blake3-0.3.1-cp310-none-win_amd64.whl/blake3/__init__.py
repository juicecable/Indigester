from .blake3 import *

__doc__ = blake3.__doc__
